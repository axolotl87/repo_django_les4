python3 manage.py makemigrations
pause
python3 manage.py migrate
pause
pause
